import React from "react";
import NumberCalculator from "./NumberCalculator";

function App() {
  return (
    <div>
      <NumberCalculator />
    </div>
  );
}

export default App;
